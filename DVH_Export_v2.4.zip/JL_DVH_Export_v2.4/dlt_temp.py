###################################################
#Jianjie Luo, Nepean Cancer Care Centre           #
#V1.0 12/02/2019                                  #
#Export selected DVHs to a csv file               #
#There are 5 files:                               #
# - DVHExportStart.Script (start file)            #
# - DVHExportChild.Script (for each structures)   #
# - calc.awk (calculate accumulated DVHs)         #
# - LockDate.awk (get appoved date with ddmmyyyy) #
# - dlt_temp.py (remove temporary files)          #
#                                                 #
#Jianjie Luo, Nepean Cancer Care Centre           #
#V2.0 11/08/2021                                  #
#Give user interface to input dose volume bin size#
#Add initial file:                                #
#  - start.Script                                 #
#                                                 #
#Jianjie Luo, Nepean Cancer Care Centre           #
#V2.1 12/08/2021                                  #
#Fixed the array 2 position shift error           #
#                                                 #
#Jianjie Luo, Nepean Cancer Care Centre           #
#V2.2 02/11/2022                                  #
#Fixed dose grid shift error & path               #
#                                                 #
#Jianjie Luo, Nepean Cancer Care Centre           #
#V2.3 08/12/2022                                  #
#Fixed the issue of dead loop when process data   #
#                                                 #
#Jianjie Luo, Nepean Cancer Care Centre           #
#V2.4 09/12/2022                                  #
#Fixed the issue of dead loop caused by random    #
#code with multiple lines                         #
###################################################

import sys
import os

os.remove('/usr/local/adacnew/PinnacleSiteData/Scripts/HotScripts/Physics/JL_DVH_Export_v2.4/lockdate.csv')

import glob
filelist = glob.glob('/usr/local/adacnew/PinnacleSiteData/Scripts/HotScripts/Physics/JL_DVH_Export_v2.4/*_*.csv')
for filePath in filelist:
	os.remove(filePath)

